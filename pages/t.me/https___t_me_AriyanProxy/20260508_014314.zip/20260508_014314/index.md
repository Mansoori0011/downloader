# Visited: https://t.me/AriyanProxy
**Time:** Fri May  8 01:43:20 UTC 2026

## Screenshot
![Screenshot](./screenshot.png)

## Raw HTML
[page.html](./page.html)

## Downloaded Media (4 files)
## Downloaded Media Files

![apple-touch-icon.png](./media/apple-touch-icon.png)
![favicon-16x16.png](./media/favicon-16x16.png)
![favicon-32x32.png](./media/favicon-32x32.png)
- [favicon.ico](./media/favicon.ico) (14 KB)

## Other Links
- [//telegram.org/](//telegram.org/)
- [//telegram.org/css/bootstrap.min.css?3](//telegram.org/css/bootstrap.min.css?3)
- [//telegram.org/css/font-roboto.css?1](//telegram.org/css/font-roboto.css?1)
- [//telegram.org/css/telegram.css?249](//telegram.org/css/telegram.css?249)
- [//telegram.org/dl?tme=c52596a22fefa8f7cf_14853952477750527969](//telegram.org/dl?tme=c52596a22fefa8f7cf_14853952477750527969)
- [//telegram.org/img/website_icon.svg?4](//telegram.org/img/website_icon.svg?4)
- [//telegram.org/js/tgwallpaper.min.js?3](//telegram.org/js/tgwallpaper.min.js?3)
- [/css/myriad.css](/css/myriad.css)
- [tg://resolve?domain=AriyanProxy](tg://resolve?domain=AriyanProxy)

## Stats
- Links: 14
- Media: 4
